﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using Nancy.Json;
using Nancy.Json.Simple;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace resouceAllocator
{
    class Program
    {
        static void Main(string[] args)
        {
            int capacity = Convert.ToInt32(Console.ReadLine());
            int hour = Convert.ToInt32(Console.ReadLine());
            int[] units = { 10, 20, 40, 80, 160, 320 };
            int[] newYorkCost = { 120, 230, 450, 774, 1400, 2820 };
            string[] unitType = { "Large", "XLarge", "2XLarge", "4XLarge", "8XLarge", "10XLarge" };
            Claculate newYourCal = new Claculate();
            string NweYorkOutput = newYourCal.Calculate(capacity, hour, units, newYorkCost, unitType, "New York");
            JObject o2 = JObject.Parse(NweYorkOutput);
            

            int[] indiaCost = { 140, 0, 413, 890, 1300, 2970 };
            Claculate indiaCalculate = new Claculate();
            string IndiaOutput = indiaCalculate.Calculate(capacity, hour, units, indiaCost, unitType, "India");
            JObject o3 = JObject.Parse(IndiaOutput);

            int[] chinaCost = { 110, 200, 0, 670, 1180, 0 };
            Claculate chinaCalculate = new Claculate();
            string chineOutput = chinaCalculate.Calculate(capacity, hour, units, chinaCost, unitType, "China");
            JObject o4 = JObject.Parse(chineOutput);
            //merging multiple json object
            JsonArray obj = new JsonArray();
            obj.Add(o2);
            obj.Add(o3);
            obj.Add(o4);
            JArray a = (JArray)JToken.FromObject(obj);
                       
            Console.WriteLine(a);


        }
    }
}
