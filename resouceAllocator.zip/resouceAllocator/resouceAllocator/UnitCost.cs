﻿using System;
using System.Collections.Generic;
using System.Text;

namespace resouceAllocator
{
    class UnitCost
    {
        public int units { get; set; }
        public int cost { get; set; }
        public double perUnitCost { get; set; }
        public string unitType { get; set; }
    }
    class output
    {
        public string region { get; set; }
        public string total_Cost { get; set; }
        public List<string> machine = new List<string>();

    }

    public class Machine
    {
        public string MachineType { get; set; }
        public int value { get; set; }
    }

}



